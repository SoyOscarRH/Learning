... Soy el chico que se acaba de inscribir

Oscar Andres Rosas Hernandez : 41702495-6

Hago libros sobre matematicas en mi tiempo libre,
así que por eso le se a LaTeX, pueden checarlo en: https://soyoscarrh.github.io/#Books