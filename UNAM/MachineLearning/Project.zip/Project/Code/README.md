javac -cp weka.jar Project.java && java -cp weka.jar:. Project
:v 
