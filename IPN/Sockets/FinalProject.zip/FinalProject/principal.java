public class principal {
  public static void main(final String[] args) {
    portDialog.show();
  }
}