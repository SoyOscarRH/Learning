class result implements java.io.Serializable {
  String md5;
  int port;

  result(String md5, int port) {
    this.md5 = md5;
    this.port = port;
  }
}